package com.codinginfinity.research.people;

/**
 * Created by rento on 4/11/2016.
 */
public class GroupSuspendedException extends Exception {
    public GroupSuspendedException() {}
    public GroupSuspendedException(String message){ super(message); }
}
