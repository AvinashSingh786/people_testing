package com.codinginfinity.research.people;


public interface ResearchCategoryState {
    
}
