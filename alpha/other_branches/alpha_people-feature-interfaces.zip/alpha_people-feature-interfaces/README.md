### Interfaces Branch

This branch needs to be sorted out before we can proceed.

The following issues have been raised:
* All source code needs to be moved from **main/** to **test/**.
* There is duplicate code within **main/**
* Once the directory structure has been sorted out and the duplicate code removed we can assign implementation of interfaces
to each team member.

*Create a "Team Suspended error"
*Change group to throw this error if a function is called while group is suspended
*If a list is passed to Group constructor, another list must contain all Person(S) relationships
*Complete User and Entity classes + interfaces
*In the java docs, say what use-cases are fulfilled
