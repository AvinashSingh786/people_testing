package com.codinginfinity.research.people;

public class DuplicateEntityExeption extends Exception {
    public DuplicateEntityExeption() {}
    public DuplicateEntityExeption(String message){ super(message); }
}