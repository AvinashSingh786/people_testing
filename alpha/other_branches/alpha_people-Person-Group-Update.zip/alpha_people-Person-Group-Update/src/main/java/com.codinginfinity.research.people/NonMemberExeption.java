package com.codinginfinity.research.people;

public class NonMemberExeption extends Exception {
    public NonMemberExeption() {}
    public NonMemberExeption(String message){ super(message); }
}