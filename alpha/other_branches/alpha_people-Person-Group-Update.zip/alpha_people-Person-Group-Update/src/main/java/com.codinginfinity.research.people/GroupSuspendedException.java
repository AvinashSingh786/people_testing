package com.codinginfinity.research.people;

public class GroupSuspendedException extends Exception {
    public GroupSuspendedException() {}
    public GroupSuspendedException(String message){ super(message); }
}
