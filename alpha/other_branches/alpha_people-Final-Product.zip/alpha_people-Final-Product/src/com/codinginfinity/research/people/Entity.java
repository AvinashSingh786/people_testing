package com.codinginfinity.research.people;

/**
 * Defines an entity (any being with substance, such as a Person or Group)
 */
public interface Entity 
{

}
