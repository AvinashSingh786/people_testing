package com.codinginfinity.research.people;

public enum ResearchGroupAssociationType 
{
    STUDENT, COLLABORATOR, MEMBER, GROUPLEADER, ADMINISTRATOR
}
